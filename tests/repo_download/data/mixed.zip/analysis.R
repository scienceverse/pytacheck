x <- read.csv('study.csv')
summary(x)
